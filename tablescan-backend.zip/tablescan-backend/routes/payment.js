const express = require("express");
const router = express.Router();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

// Process Payment
router.post("/pay", async (req, res) => {
    const { amount, currency, source } = req.body;
    const charge = await stripe.charges.create({ amount, currency, source });
    res.status(200).send("Payment successful");
});

module.exports = router;
