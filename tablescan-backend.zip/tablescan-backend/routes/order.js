const express = require("express");
const router = express.Router();
const Order = require("../models/Order");

// Place Order
router.post("/place", async (req, res) => {
    const { customerId, items, totalAmount } = req.body;
    const newOrder = new Order({ customerId, items, totalAmount, orderStatus: "Pending", orderDateTime: new Date() });
    await newOrder.save();
    res.status(201).send("Order placed");
});

// Get Orders
router.get("/", async (req, res) => {
    const orders = await Order.find();
    res.status(200).json(orders);
});

module.exports = router;
