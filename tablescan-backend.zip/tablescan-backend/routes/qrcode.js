const express = require("express");
const router = express.Router();
const QRCode = require("qrcode");

// Generate QR Code
router.post("/generate", async (req, res) => {
    const { tableNumber } = req.body;
    const qrData = `Table-${tableNumber}`;
    const qrImage = await QRCode.toDataURL(qrData);
    res.status(200).send(qrImage);
});

module.exports = router;
