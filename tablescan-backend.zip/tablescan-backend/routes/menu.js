const express = require("express");
const router = express.Router();
const Menu = require("../models/Menu");
const { verifyToken } = require("../middleware/auth"); // Import JWT Middleware

// 🟢 Fetch all menu items (Public Route)
router.get("/", async (req, res) => {
    try {
        const menuItems = await Menu.find();
        res.json({ message: "Menu API is working!", items: menuItems });
    } catch (error) {
        res.status(500).json({ message: "Error fetching menu", error });
    }
});

// 🟢 Fetch a single menu item by ID (Public Route)
router.get("/:id", async (req, res) => {
    try {
        const menuItem = await Menu.findById(req.params.id.trim()); // Trim extra spaces or newlines
        if (!menuItem) return res.status(404).json({ message: "Menu item not found!" });

        res.json({ message: "Menu item found!", item: menuItem });
    } catch (error) {
        res.status(500).json({ message: "Error fetching menu item", error });
    }
});

// 🟢 Add a new menu item (Protected Route)
router.post("/", verifyToken, async (req, res) => {
    try {
        const { itemName, description, price, availabilityStatus } = req.body;

        // ✅ Validate request body
        if (!itemName || !description || !price || availabilityStatus === undefined) {
            return res.status(400).json({ message: "All fields (itemName, description, price, availabilityStatus) are required!" });
        }

        const newItem = new Menu({ itemName, description, price, availabilityStatus });
        await newItem.save();
        res.status(201).json({ message: "Menu item added successfully!", item: newItem });
    } catch (error) {
        res.status(500).json({ message: "Error adding menu item", error });
    }
});

// 🟢 Update an existing menu item by ID (Protected Route)
router.put("/:id", verifyToken, async (req, res) => {
    try {
        const updatedItem = await Menu.findByIdAndUpdate(req.params.id.trim(), req.body, { new: true });
        if (!updatedItem) return res.status(404).json({ message: "Menu item not found!" });

        res.json({ message: "Menu item updated!", item: updatedItem });
    } catch (error) {
        res.status(500).json({ message: "Error updating menu item", error });
    }
});

// 🟢 Delete a menu item by ID (Protected Route)
router.delete("/:id", verifyToken, async (req, res) => {
    try {
        const deletedItem = await Menu.findByIdAndDelete(req.params.id.trim());
        if (!deletedItem) return res.status(404).json({ message: "Menu item not found!" });

        res.json({ message: "Menu item deleted successfully!", item: deletedItem });
    } catch (error) {
        res.status(500).json({ message: "Error deleting menu item", error });
    }
});

module.exports = router;
