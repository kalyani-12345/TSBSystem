const express = require("express");
const router = express.Router();
const User = require("../models/User");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// ✅ Test Route (Check if auth routes are working)
router.get("/", (req, res) => {
  res.status(200).json({ message: "Auth API is working!" });
});

// ✅ User Registration
router.post("/register", async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Hash password before saving
    console.log("🔍 Raw Password Before Hashing:", password);
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("🔍 Hashed Password:", hashedPassword);

    const user = new User({ name, email, phone, password: hashedPassword });
    await user.save();

    res.status(201).json({
      message: "User registered successfully",
      user: { name, email, phone },
    });
  } catch (error) {
    console.error("❌ Registration Error:", error);
    res.status(500).json({ message: "Error registering user", error: error.message });
  }
});

// ✅ User Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log("🔍 Email received:", email);
    console.log("🔍 Password received:", password);

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      console.log("❌ User not found in DB");
      return res.status(400).json({ message: "Invalid credentials" });
    }

    console.log("🔍 User found:", user);
    console.log("🔍 Stored Hash in DB:", user.password);

    // Compare passwords
    const isMatch = await bcrypt.compare(password, user.password);
    console.log("🔍 Password Match Result:", isMatch ? "✅ Match!" : "❌ No Match");

    if (!isMatch) {
      console.log("❌ Passwords do not match");
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    console.log("✅ Login Successful!");
    res.status(200).json({
      message: "Login successful",
      token,
      user: { name: user.name, email: user.email, phone: user.phone },
    });

  } catch (error) {
    console.error("❌ Login Error:", error);
    res.status(500).json({ message: "Error logging in", error });
  }
});

// ✅ JWT Middleware (Protect Routes)
const verifyToken = (req, res, next) => {
  const token = req.header("Authorization");
  if (!token) return res.status(403).json({ message: "Access denied, no token provided" });

  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    req.user = verified;
    next();
  } catch (error) {
    res.status(400).json({ message: "Invalid or expired token" });
  }
};

// ✅ Protected Route Example
router.get("/profile", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select("-password");
    if (!user) return res.status(404).json({ message: "User not found" });

    res.status(200).json({ message: "User profile fetched successfully", user });
  } catch (error) {
    console.error("❌ Profile Fetch Error:", error);
    res.status(500).json({ message: "Error fetching profile", error });
  }
});

// ✅ Logout Route (Client-side handles token removal)
router.post("/logout", (req, res) => {
  res.status(200).json({ message: "User logged out successfully" });
});

module.exports = router;
