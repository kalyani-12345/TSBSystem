require("dotenv").config(); // Load environment variables

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// ✅ Check if environment variables are loaded
console.log("🔍 Checking environment variables:");
console.log("PORT:", process.env.PORT || 5000);
console.log("MONGO_URI:", process.env.MONGO_URI ? "✅ Loaded" : "❌ MISSING");
console.log("JWT_SECRET:", process.env.JWT_SECRET ? "✅ Loaded" : "❌ MISSING");
console.log("STRIPE_SECRET_KEY:", process.env.STRIPE_SECRET_KEY ? "✅ Loaded" : "❌ MISSING");

// ❌ Stop server if MONGO_URI is missing
if (!process.env.MONGO_URI) {
  console.error("❌ ERROR: MONGO_URI is missing in .env file!");
  process.exit(1);
}

// 🔗 Connect to MongoDB (Fixed warnings: removed deprecated options)
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => {
    console.error("❌ MongoDB Connection Error:", err);
    process.exit(1);
  });

// 🛠 Import Routes
const authRoutes = require("./routes/auth");
const menuRoutes = require("./routes/menu");
const orderRoutes = require("./routes/order");
const paymentRoutes = require("./routes/payment");
const qrCodeRoutes = require("./routes/qrcode");

// 🛠 Register Routes
app.use("/auth", authRoutes);
app.use("/menu", menuRoutes);
app.use("/order", orderRoutes);
app.use("/payment", paymentRoutes);
app.use("/qrcode", qrCodeRoutes);

// ✅ Test API Route
app.get("/", (req, res) => {
  res.send("🚀 Server is running!");
});

// 🛠 Debugging: List all registered routes
console.log("🛠 Registered Routes:");
app._router.stack.forEach((r) => {
  if (r.route && r.route.path) {
    console.log(`✅ Route: ${r.route.path}`);
  }
});

// 🚀 Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
