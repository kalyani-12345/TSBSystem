const bcrypt = require("bcrypt");

const storedHash = "$2b$10$dXV4v3qQYM9Cb1cYtUcE2u5ZSOEpxeo/bLvnGJuLjPyOmJidHFQo2"; // Use the new hash
const enteredPassword = "password123"; // Enter the exact password you used during registration

async function checkPassword() {
  console.log("🔍 Checking Password...");
  const isMatch = await bcrypt.compare(enteredPassword, storedHash);
  console.log(isMatch ? "✅ Match!" : "❌ No Match");
}

checkPassword();
